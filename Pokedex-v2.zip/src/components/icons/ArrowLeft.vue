<template>
  <svg
    version="1.1"
    id="Layer_1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    viewBox="0 0 458.852 458.852"
    xml:space="preserve"
  >
    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
    <g
      id="SVGRepo_tracerCarrier"
      stroke-linecap="round"
      stroke-linejoin="round"
    ></g>
    <g id="SVGRepo_iconCarrier">
      <g>
        <path
          d="M115.086,229.426l228.679,229.426V0L115.086,229.426z M313.765,386.258L157.444,229.426L313.765,72.594V386.258z"
        ></path>
      </g>
    </g>
  </svg>
</template>

<script lang="ts">
export default {
  name: 'ArrowLeftIcon',
};
</script>
